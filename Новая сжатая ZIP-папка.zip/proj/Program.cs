﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;
using WarehouseSystem.DataAccess;
using WarehouseSystem.Services;

namespace WarehouseSystem
{
    public class ConsoleInterface
    {
        private readonly WarehouseService _warehouseService;
        private readonly ReportService _reportService;
        private readonly ILogger<ConsoleInterface> _logger;

        public ConsoleInterface(WarehouseService warehouseService, ReportService reportService, ILogger<ConsoleInterface> logger)
        {
            _warehouseService = warehouseService ?? throw new ArgumentNullException(nameof(warehouseService));
            _reportService = reportService ?? throw new ArgumentNullException(nameof(reportService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task RunAsync()
        {
            while (true)
            {
                Console.WriteLine("=== Информационная система склада ===");
                Console.WriteLine("1. Добавить товар");
                Console.WriteLine("2. Переместить товар");
                Console.WriteLine("3. Провести инвентаризацию");
                Console.WriteLine("4. Сгенерировать отчет");
                Console.WriteLine("5. Выход");
                Console.Write("Выберите действие (1-5): ");

                string? choice = Console.ReadLine()?.Trim();

                try
                {
                    switch (choice)
                    {
                        case "1":
                            await AddProductAsync();
                            break;
                        case "2":
                            await MoveProductAsync();
                            break;
                        case "3":
                            await PerformInventoryAsync();
                            break;
                        case "4":
                            await GenerateStockReportAsync();
                            break;
                        case "5":
                            Console.WriteLine("Выход...");
                            return;
                        default:
                            Console.WriteLine("Некорректная команда.");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError($"Ошибка: {ex.Message}");
                    Console.WriteLine($"Ошибка: {ex.Message}");
                }

                Console.WriteLine("\nНажмите Enter для продолжения...");
                Console.ReadLine();
                Console.Clear();
            }
        }

        private async Task AddProductAsync()
        {
            Console.Write("Название товара: ");
            string? name = Console.ReadLine()?.Trim();
            if (string.IsNullOrEmpty(name)) throw new ArgumentException("Название не может быть пустым.");

            Console.Write("SKU: ");
            string? sku = Console.ReadLine()?.Trim();
            if (string.IsNullOrEmpty(sku)) throw new ArgumentException("SKU не может быть пустым.");

            Console.Write("Цена: ");
            if (!decimal.TryParse(Console.ReadLine(), out decimal price) || price <= 0)
                throw new ArgumentException("Цена должна быть положительным числом.");

            var productId = await _warehouseService.AddProductAsync(name, sku, price);
            Console.WriteLine(productId.HasValue ? $"Товар добавлен, ID: {productId}" : "Не удалось добавить товар.");
        }

        private async Task MoveProductAsync()
        {
            Console.Write("ID товара: ");
            if (!int.TryParse(Console.ReadLine(), out int productId) || productId <= 0)
                throw new ArgumentException("ID товара должен быть положительным числом.");

            Console.Write("ID исходного склада: ");
            if (!int.TryParse(Console.ReadLine(), out int fromWarehouseId) || fromWarehouseId <= 0)
                throw new ArgumentException("ID склада должен быть положительным числом.");

            Console.Write("ID целевого склада: ");
            if (!int.TryParse(Console.ReadLine(), out int toWarehouseId) || toWarehouseId <= 0)
                throw new ArgumentException("ID склада должен быть положительным числом.");

            Console.Write("Количество: ");
            if (!int.TryParse(Console.ReadLine(), out int quantity) || quantity <= 0)
                throw new ArgumentException("Количество должно быть положительным числом.");

            bool success = await _warehouseService.MoveProductAsync(productId, fromWarehouseId, toWarehouseId, quantity);
            Console.WriteLine(success ? "Товар перемещен." : "Не удалось переместить товар.");
        }

        private async Task PerformInventoryAsync()
        {
            Console.Write("ID склада: ");
            if (!int.TryParse(Console.ReadLine(), out int warehouseId) || warehouseId <= 0)
                throw new ArgumentException("ID склада должен быть положительным числом.");

            var actualQuantities = new Dictionary<int, int>();
            while (true)
            {
                Console.Write("ID товара (0 для завершения): ");
                if (!int.TryParse(Console.ReadLine(), out int productId))
                    throw new ArgumentException("ID товара должен быть числом.");
                if (productId == 0) break;

                Console.Write("Фактическое количество: ");
                if (!int.TryParse(Console.ReadLine(), out int quantity) || quantity < 0)
                    throw new ArgumentException("Количество должно быть неотрицательным числом.");

                actualQuantities[productId] = quantity;
            }

            bool success = await _warehouseService.PerformInventoryAsync(warehouseId, actualQuantities);
            Console.WriteLine(success ? "Инвентаризация завершена." : "Ошибка инвентаризации.");
        }

        private async Task GenerateStockReportAsync()
        {
            Console.Write("ID склада: ");
            if (!int.TryParse(Console.ReadLine(), out int warehouseId) || warehouseId <= 0)
                throw new ArgumentException("ID склада должен быть положительным числом.");

            string report = await _reportService.GenerateStockReportAsync(warehouseId);
            Console.WriteLine("\n" + report);
        }
    }

    class Program
    {
        static async Task Main(string[] args)
        {
            var services = new ServiceCollection();
            services.AddDbContext<WarehouseDbContext>(options =>
                options.UseSqlite("Data Source=warehouse.db"));
            services.AddLogging(builder => builder.AddConsole());
            services.AddScoped<DatabaseManager>();
            services.AddScoped<WarehouseService>();
            services.AddScoped<ReportService>();
            services.AddScoped<ConsoleInterface>();

            var serviceProvider = services.BuildServiceProvider();

            using (var scope = serviceProvider.CreateScope())
            {
                var dbContext = scope.ServiceProvider.GetService<WarehouseDbContext>();
                if (dbContext == null)
                {
                    Console.WriteLine("Ошибка: не удалось инициализировать контекст базы данных.");
                    return;
                }
                await dbContext.Database.EnsureCreatedAsync();
            }

            var consoleInterface = serviceProvider.GetService<ConsoleInterface>();
            if (consoleInterface == null)
            {
                Console.WriteLine("Ошибка: не удалось инициализировать консольный интерфейс.");
                return;
            }
            await consoleInterface.RunAsync();
        }
    }
}