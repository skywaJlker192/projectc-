using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WarehouseSystem.DataAccess
{
    public class WarehouseDbContext : DbContext
    {
        public DbSet<Product> Products { get; set; } = null!;
        public DbSet<Inventory> Inventory { get; set; } = null!;
        public DbSet<Warehouse> Warehouses { get; set; } = null!;

        public WarehouseDbContext(DbContextOptions<WarehouseDbContext> options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Product>()
                .HasIndex(p => p.Sku)
                .IsUnique();
            modelBuilder.Entity<Inventory>()
                .HasIndex(i => new { i.ProductId, i.WarehouseId })
                .IsUnique();

            modelBuilder.Entity<Warehouse>().HasData(
                new Warehouse { WarehouseId = 1, Location = "����� A" },
                new Warehouse { WarehouseId = 2, Location = "����� B" }
            );
        }
    }

    public class DatabaseManager
    {
        private readonly WarehouseDbContext _context;
        private readonly ILogger<DatabaseManager> _logger;

        public DatabaseManager(WarehouseDbContext context, ILogger<DatabaseManager> logger)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task<List<Inventory>> GetInventoryByWarehouseAsync(int warehouseId)
        {
            try
            {
                return await _context.Inventory
                    .Where(i => i.WarehouseId == warehouseId)
                    .Include(i => i.Product)
                    .Include(i => i.Warehouse)
                    .ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError($"������ ��� ��������� inventory: {ex.Message}");
                return new List<Inventory>();
            }
        }

        public async Task<int?> CreateProductAsync(string name, string sku, decimal price)
        {
            try
            {
                var product = new Product { Name = name, Sku = sku, Price = price };
                _context.Products.Add(product);
                await _context.SaveChangesAsync();
                _logger.LogInformation($"������ �����: {name}, ID: {product.ProductId}");
                return product.ProductId;
            }
            catch (DbUpdateException ex)
            {
                _logger.LogError($"������ ��� �������� ������: {ex.Message}");
                return null;
            }
        }

        public async Task<Product?> GetProductAsync(int productId)
        {
            try
            {
                return await _context.Products.FindAsync(productId);
            }
            catch (Exception ex)
            {
                _logger.LogError($"������ ��� ��������� ������: {ex.Message}");
                return null;
            }
        }

        public async Task<bool> UpdateProductAsync(int productId, string? name = null, string? sku = null, decimal? price = null)
        {
            try
            {
                var product = await _context.Products.FindAsync(productId);
                if (product == null) return false;

                if (!string.IsNullOrEmpty(name)) product.Name = name;
                if (!string.IsNullOrEmpty(sku)) product.Sku = sku;
                if (price.HasValue) product.Price = price.Value;

                await _context.SaveChangesAsync();
                _logger.LogInformation($"�������� �����: {productId}");
                return true;
            }
            catch (DbUpdateException ex)
            {
                _logger.LogError($"������ ��� ���������� ������: {ex.Message}");
                return false;
            }
        }

        public async Task<bool> DeleteProductAsync(int productId)
        {
            try
            {
                var product = await _context.Products.FindAsync(productId);
                if (product == null) return false;

                _context.Products.Remove(product);
                await _context.SaveChangesAsync();
                _logger.LogInformation($"������ �����: {productId}");
                return true;
            }
            catch (DbUpdateException ex)
            {
                _logger.LogError($"������ ��� �������� ������: {ex.Message}");
                return false;
            }
        }

        public async Task<int?> AddInventoryAsync(int productId, int warehouseId, int quantity)
        {
            try
            {
                var inventory = new Inventory { ProductId = productId, WarehouseId = warehouseId, Quantity = quantity };
                _context.Inventory.Add(inventory);
                await _context.SaveChangesAsync();
                _logger.LogInformation($"��������� ������ � inventory: ProductId={productId}, WarehouseId={warehouseId}");
                return inventory.InventoryId;
            }
            catch (DbUpdateException ex)
            {
                _logger.LogError($"������ ��� ���������� � inventory: {ex.Message}");
                return null;
            }
        }

        public async Task<Inventory?> GetInventoryAsync(int productId, int warehouseId)
        {
            try
            {
                return await _context.Inventory
                    .Include(i => i.Product)
                    .Include(i => i.Warehouse)
                    .FirstOrDefaultAsync(i => i.ProductId == productId && i.WarehouseId == warehouseId);
            }
            catch (Exception ex)
            {
                _logger.LogError($"������ ��� ��������� ������ inventory: {ex.Message}");
                return null;
            }
        }

        public async Task<bool> UpdateInventoryAsync(int inventoryId, int quantity)
        {
            try
            {
                var inventory = await _context.Inventory.FindAsync(inventoryId);
                if (inventory == null) return false;

                inventory.Quantity = quantity;
                await _context.SaveChangesAsync();
                _logger.LogInformation($"��������� ������ inventory: {inventoryId}");
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError($"������ ��� ���������� inventory: {ex.Message}");
                return false;
            }
        }
    }
}